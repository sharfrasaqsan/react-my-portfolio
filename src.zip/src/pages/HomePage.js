import React from "react";
import Hero from "../components/Hero";

const HomePage = () => {
  return (
    <>
      <Hero />
    </>
  );
};

export default HomePage;
