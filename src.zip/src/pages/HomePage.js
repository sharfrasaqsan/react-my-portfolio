import Hero from "../components/Hero";

const HomePage = () => {
  return (
    <main className="container-xxl py-5">
      <Hero />
    </main>
  );
};

export default HomePage;
