import ProjectList from "../components/ProjectList";

const Projects = () => {
  return (
    <section>
      <ProjectList />
    </section>
  );
};

export default Projects;
