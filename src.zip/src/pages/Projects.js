import ProjectList from "../components/ProjectList";

const Projects = () => {
  return (
    <>
      <ProjectList />
    </>
  );
};

export default Projects;
